﻿using EmpMgt_DAL.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmpMgt_BAL.Interface
{
   public interface IEmployeeservice
    {

        List<Employee> GetAllEmployee();

        public Employee GetEmployeeById(Guid id);

        Employee AddEmployee(Employee employee);

        bool DeleteEmployee(Guid guid);

    }
}
