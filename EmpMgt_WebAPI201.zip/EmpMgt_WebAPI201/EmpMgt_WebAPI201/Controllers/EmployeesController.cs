using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmpMgt_DAL.Models;
using EmpMgt_BAL.Service;
using EmpMgt_DAL.Repository;
using EmpMgt_BAL.Interface;
namespace EmpMgt_WebAPI201.Controllers
{

    [ApiController]
//    [Route("[controller]")]

    public class EmployeesController : ControllerBase
    {

        private readonly IEmployeeservice _employeeService;

        public EmployeesController(IEmployeeservice employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetEmployees()
        {
            try
            {
              var emp=  _employeeService.GetAllEmployee();
                if (emp == null || emp.Count ==0)
                 
                return BadRequest();
                else
                    return Ok(emp);
            }

            catch (Exception ex)
            { return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetEmployee(Guid id)
        {
          
            try
            {
                if (id == null)
                {
                    return BadRequest();
                }
                else
                {
                    var emp = _employeeService.GetEmployeeById(id);
                    if (emp != null)
                        return Ok(emp);
                    else
                    {
                        return NotFound();
                    }

                }
            }

            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("api/[controller]")]
        public IActionResult GetEmployee(Employee employee)   //Guid guid)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(400);

                _employeeService.AddEmployee(employee);
                // return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + employee.Id, employee);

                return CreatedAtAction("Get", new { id = employee.Id }, employee);
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteEmployee(Guid id)//Guid guid)
        {
            try
            {
                var employee = _employeeService.GetEmployeeById(id);

                if (employee != null)
                {
                    _employeeService.DeleteEmployee(employee.Id);
                    return Ok();
                }
                else
                    return NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }

        }
        //Remove Items

    }
}
