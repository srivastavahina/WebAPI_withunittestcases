﻿using EmpMgt_DAL.Data;
using EmpMgt_DAL.Interface;
using EmpMgt_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpMgt_DAL.Repository
{
    public class RepositoryEmployee : IEmployeeData
    {
 

        private ApplicationDbContext _empcontext;
        public RepositoryEmployee(ApplicationDbContext employeeContext)
        {
            _empcontext = employeeContext;
        }
        public Employee AddEmployee(Employee employee)
        {
            try
            {
                employee.Id = Guid.NewGuid();
                _empcontext.Employees.Add(employee);
                _empcontext.SaveChanges();
                return employee;
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public void DeleteEmployee(Employee employee)
        {
            try
            {
                _empcontext.Employees.Remove(employee);
                _empcontext.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw new Exception(ex.Message, ex);
            }

        }

        public Employee GetEmployee(Guid id)
        {
            try
            {
                return _empcontext.Employees.SingleOrDefault(x => x.Id == id);
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public List<Employee> GetEmployees()
        {try
            {
                return _empcontext.Employees.ToList();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw new Exception(ex.Message, ex);
            }

          
        }
    }
}

