﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using EmpMgt_DAL.Models;

namespace EmpMgt_DAL.Interface
{
    public interface IEmployeeData
    {

        List<Employee> GetEmployees();

        public Employee GetEmployee(Guid id);

        Employee AddEmployee(Employee employee);

        void DeleteEmployee(Employee employee);
    }


}