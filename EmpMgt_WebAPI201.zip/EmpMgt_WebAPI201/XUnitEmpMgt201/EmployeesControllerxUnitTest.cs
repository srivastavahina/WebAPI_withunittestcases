using System;
using Xunit;
using EmpMgt_BAL.Service;
using EmpMgt_DAL.Models;
using EmpMgt_DAL.Interface;
using EmpMgt_WebAPI201.Controllers;
using Moq;
using EmpMgt_BAL.Interface;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace XUnitEmpMgt201
{
    public class EmployeesControllerxUnitTest
    {
        private readonly EmployeesController _empcontroller_sut;
        private readonly Mock<IEmployeeservice> _empservicemock = new Mock<IEmployeeservice>();

        private  Guid Id = Guid.NewGuid();
        private const string Name = "George";
        private const string  Competency = "C3";

        public EmployeesControllerxUnitTest()
        {
            _empcontroller_sut = new EmployeesController(_empservicemock.Object);
        }
        [Fact]
        public void EmployeeController_IsInstanceOf_EmployeeController_ReceivingEmployeeServiceOnCreation_Test()
        {
            // Arrange
            var controller = new EmployeesController(_empservicemock.Object);

            // Act | Assert
            Assert.IsType<EmployeesController>(controller);
        }

        private List<Employee> CreateEmployeeList()
        {
            var Employee = new List<Employee>
            {
                new Employee(),
                new Employee()
            };
            return Employee;
        }
        [Fact]
        public void EmployeeController_Get_EmployeeFromService_ReturnsOkResultWithEmployeeListAsContent_Test()
        {
            // Arrange
            var Employee = CreateEmployeeList();
            _empservicemock.Setup(m => m.GetAllEmployee()).Returns(Employee);
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.GetEmployees() as OkObjectResult;
            int resultvalue = ((List<Employee>)result.Value).Count;

            // Assert
           
            Assert.NotNull(result);
            Assert.Equal(Employee.Count, resultvalue);
            Assert.IsType<OkObjectResult>(result);


        }



        [Fact]
        public void EmployeeController_Get_EmployeeFromService_ListIsEmpty_BadRequestFoundResultIsReturned_Test()
        {
            // Arrange
            _empservicemock.Setup(m => m.GetAllEmployee()).Returns(new List<Employee>());
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.GetEmployees() as BadRequestResult;

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }

        private Employee CreateDefaultEmployeeObject()
        {
            return new Employee
            {
                Id = Id,
                Name = Name,
                Competency = Competency
            };
        }
        [Fact]
        public void EmployeeController_Get_EmployeeByIdFromService_ReturnsOkWithEmployeeEntityAsContent_Test()
        {
            // Arrange
            var employee = CreateDefaultEmployeeObject();
            _empservicemock.Setup(m => m.GetEmployeeById(It.IsAny<Guid>())).Returns(employee);
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.GetEmployee(employee.Id) as OkObjectResult;

            var resultvalue = result.Value;


            // Assert
            Assert.Equal(employee, resultvalue);
            Assert.NotNull(resultvalue);
            
        }

        [Fact]
        public void AddEmployee_InValidEmployee()
        {
            //Arrange
            var empId = Guid.NewGuid();
            Employee Expectedemp = new Employee() { Id = empId, Name = "testEmployee1" };
            _empservicemock.Setup(p => p.AddEmployee(Expectedemp)).Returns(Expectedemp);
            _empcontroller_sut.ModelState.AddModelError("fakeError", "fakeError");
            //Act
            IActionResult res = _empcontroller_sut.GetEmployee(Expectedemp);
            //Assert
            Assert.IsType<BadRequestObjectResult>(res);

        }
        [Fact]
        public void EmployeeController_Get_EmployeeByIdFromService_EmployeeCouldNotBeFound_ReturnsNotFoundResult_Test()
        {
            // Arrange
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.GetEmployee(Id) as NotFoundResult;

            // Assert
           Assert.NotNull(result);
        }

      

        [Fact]
        public void EmployeeController_Post_EmployeeToService_ReturnsCreatedResult_Test()
        {
            // Arrange
            var employee = CreateDefaultEmployeeObject();

            _empservicemock.Setup(p => p.AddEmployee(employee)).Returns(employee);

            // Act

            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.GetEmployee(employee) as CreatedAtActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(employee, result.Value);
        }

        [Fact]
        public void EmployeeController_Post_EmployeeEntityIsNull_ReturnsBadRequest_Test()
        {
            // Arrange
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.GetEmployee(null) as BadRequestResult;

            // Assert
           Assert.Null(result);
        }

        [Fact]
        public void EmployeeController_Delete_EmployeeDeleted_ReturnsOkResult_Test()
        {
            // Arrange
            var employee = new Employee();
            _empservicemock.Setup(m => m.GetEmployeeById(It.IsAny<Guid>())).Returns(employee);
            _empservicemock.Setup(m => m.DeleteEmployee(It.IsAny<Guid>())).Verifiable();
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.DeleteEmployee(Id) as OkResult;

            // Assert
            Assert.NotNull(result);
           
        }

        [Fact]
        public void EmployeeController_Delete_PersonIdIsNotValid_ReturnsBadRequest_Test()
        {
            // Arrange
            var controller = new EmployeesController(_empservicemock.Object);

            // Act
            var result = controller.DeleteEmployee(It.IsAny<Guid>()) as BadRequestObjectResult;

            // Assert
            Assert.Null(result);
          
        }

        [Fact]
        public void GetAllEmployee_Count_Check()
        {


            List<Employee> Expectedemp = new List<Employee>()
                                            { new Employee() { Id = Guid.NewGuid(), Name = "testEmployee1", Competency = "C3" },
                                              new Employee() { Id = Guid.NewGuid(), Name = "testEmployee2", Competency = "C3" },
                                              new Employee() { Id = Guid.NewGuid(), Name = "testEmployee3", Competency = "C3" } };
            _empservicemock.Setup(p => p.GetAllEmployee()).Returns(Expectedemp);

            Microsoft.AspNetCore.Mvc.OkObjectResult res = _empcontroller_sut.GetEmployees() as Microsoft.AspNetCore.Mvc.OkObjectResult;

            int actualmockres = ((List<Employee>)res.Value).Count;

            Assert.Equal(Expectedemp.Count, actualmockres);
            Assert.IsType<OkObjectResult>(res);

        }

        [Fact]
        public void GetAllEmployee_NoEmployeeExist()
        {


            List<Employee> Expectedemp = new List<Employee>();

            _empservicemock.Setup(p => p.GetAllEmployee()).Returns(Expectedemp);

            IActionResult res = _empcontroller_sut.GetEmployees();

            Assert.IsType<BadRequestResult>(res);

        }


    }


}

